let nameInput = document.getElementById("name");
let courseInput = document.getElementById("course");
let result = document.getElementById("result");

// Click event
document.getElementById("clickBtn").addEventListener("click", function () {
  result.textContent = "Button clicked!";
});

// Input event
nameInput.addEventListener("input", function () {
  document.getElementById("inputMessage").textContent =
    "Name entered: " + nameInput.value;
});

// Change event
courseInput.addEventListener("change", function () {
  document.getElementById("courseMessage").textContent =
    "Selected Course: " + courseInput.value;
});

// Submit event
document
  .getElementById("studentForm")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    result.textContent =
      "Registration successful! Name: " +
      nameInput.value +
      ", Course: " +
      courseInput.value;
  });

// Mouse event
document
  .getElementById("eventMessage")
  .addEventListener("mouseover", function () {
    this.style.color = "blue";
  });

// Keyboard event
nameInput.addEventListener("keydown", function (event) {
  if (event.key === "Enter") {
    event.preventDefault();
    result.textContent = "Enter key pressed in the name field.";
  }
});
