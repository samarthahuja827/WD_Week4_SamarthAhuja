let tasks = [];

let taskForm = document.getElementById("taskForm");
let taskInput = document.getElementById("taskInput");
let taskList = document.getElementById("taskList");
let message = document.getElementById("message");

function displayTasks() {
  taskList.innerHTML = "";

  for (let i = 0; i < tasks.length; i++) {
    let li = document.createElement("li");

    let checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = tasks[i].completed;

    let taskText = document.createElement("span");
    taskText.textContent = tasks[i].text;

    if (tasks[i].completed) {
      taskText.style.textDecoration = "line-through";
    }

    let deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";

    checkbox.addEventListener("change", function () {
      tasks[i].completed = checkbox.checked;
      displayTasks();
    });

    deleteButton.addEventListener("click", function () {
      tasks.splice(i, 1);
      displayTasks();
    });

    li.appendChild(checkbox);
    li.appendChild(taskText);
    li.appendChild(deleteButton);

    taskList.appendChild(li);
  }
}

function addTask(taskText) {
  let task = {
    text: taskText,
    completed: false,
  };

  tasks.push(task);
  displayTasks();
}

taskForm.addEventListener("submit", function (event) {
  event.preventDefault();

  let taskText = taskInput.value.trim();

  if (taskText !== "") {
    addTask(taskText);
    message.textContent = "Task added successfully!";
    taskInput.value = "";
  }
});
