let students = ["Rohit", "Aman", "Priya", "Neha"];

console.log("Original Array:", students);

console.log("First Element:", students[0]);
console.log("Third Element:", students[2]);

students.push("Aditya");
console.log("After Adding Aditya:", students);

students.pop();
console.log("After Removing Last Element:", students);

students[1] = "Nitish";
console.log("After Updating Second Element:", students);

console.log("Student Names:");
for (let i = 0; i < students.length; i++) {
  console.log(students[i]);
}

console.log("Total Elements:", students.length);
console.log("Is Priya Present?", students.includes("Priya"));
