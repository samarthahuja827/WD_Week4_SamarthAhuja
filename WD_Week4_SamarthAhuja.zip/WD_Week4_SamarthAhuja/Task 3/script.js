let student1 = {
  name: "Rohit",
  age: 19,
  course: "B.Tech",
};

let student2 = {
  name: "Priya",
  age: 20,
  course: "BCA",
};

let student3 = {
  name: "Aman",
  age: 19,
  course: "B.Tech",
};

console.log("Student 1:", student1);
console.log("Student 2:", student2);
console.log("Student 3:", student3);

console.log("Student 1 Name:", student1.name);
console.log("Student 2 Age:", student1.age);

console.log("Student 1 Values:", Object.values(student1));

student1.age = 20;
console.log("After Updating Age:", student1);

student1.marks = 92;
console.log("After Adding Marks:", student1);

delete student1.course;
console.log("After Removing Course:", student1);
