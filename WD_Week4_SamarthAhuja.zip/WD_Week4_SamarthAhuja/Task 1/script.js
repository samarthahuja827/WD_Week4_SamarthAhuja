function calculateTotalMarks(marks1, marks2, marks3) {
  let sum = marks1 + marks2 + marks3;
  return sum;
}

let totalMarks = calculateTotalMarks(92, 95, 80);
console.log("Total Marks:", totalMarks);

function calculatePercentage(totalMarks) {
  return (totalMarks / 300) * 100;
}

let percentage = calculatePercentage(totalMarks);
console.log("Percentage:", percentage + "%");

const greetStudent = (name) => {
  return "Hello " + name;
};

console.log(greetStudent("Rohit"));
