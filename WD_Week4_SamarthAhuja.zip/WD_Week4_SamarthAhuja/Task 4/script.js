let heading = document.getElementById("heading");
let message = document.getElementById("message");
let student = document.getElementById("student");

// Changing text content
document.getElementById("textBtn").addEventListener("click", function () {
  message.textContent = "Student information updated successfully!";
});

// Changing HTML content
document.getElementById("htmlBtn").addEventListener("click", function () {
  student.innerHTML = "<h2>Rohit</h2><p>Course: B.Tech</p><p>Marks: 92</p>";
});

// Changing CSS styles
document.getElementById("styleBtn").addEventListener("click", function () {
  heading.style.color = "blue";
  heading.style.fontSize = "32px";
});

// Adding elements
document.getElementById("addBtn").addEventListener("click", function () {
  let newStudent = document.createElement("p");
  newStudent.textContent = "New Student Added";
  newStudent.className = "newStudent";
  document.body.appendChild(newStudent);
});

// Removing elements
document.getElementById("removeBtn").addEventListener("click", function () {
  let newStudent = document.querySelector(".newStudent");

  if (newStudent) {
    newStudent.remove();
  }
});
